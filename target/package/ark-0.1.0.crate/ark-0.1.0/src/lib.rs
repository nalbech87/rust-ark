#[macro_use] extern crate serde_derive;
extern crate reqwest;

mod manager;
mod models;
